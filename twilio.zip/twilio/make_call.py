import os
from twilio.rest import Client
from twilio.twiml.voice_response import VoiceResponse


account_sid ="AC2e16b16e14a7cf8fcff2d1bf0df8d36f"
auth_token="d9764499f0ead2966ced00f074630478"

client=Client(account_sid,auth_token)

call =client.calls.create(

    to="+918778603754",
    from_="+17866613976",
     url=" https://9c2239dc.ngrok.io/voice"
)
#call =client.calls.create(

 
 #  to="+919444419262",
  # from_="+17866613976",
  #url="http://65f46640.ngrok.io/voice"
#)
client.messages.create(
 to="+918778603754",
from_="+17866613976",
body="YOU ARE NOW VERIFIED"
)
calls = client.calls.list(limit=20)

for record in calls:
    print(record.from_)
    