from django import forms

class ContactForm(forms.Form):
    aadhar=forms.IntegerField(label="aadhar")