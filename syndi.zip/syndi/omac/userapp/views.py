from django.shortcuts import render
from django.http import HttpResponse
from .forms import ContactForm

def index(request):
    if request.method == 'POST':
        form=ContactForm(request.POST)
        if form.is_valid():
            aadhar=form.cleaned_data['aadhar']

    form=ContactForm()
    return render(request,'userapp/form.html',{'form':form},)

# Create your views here.
